import javax.swing.JButton;
import javax.swing.JLabel;

public class Calculator {
	private static int sum;
	public static int avg;
	private static Cell c;

	public static void calculate() {
		
		/* Cell.cell is a button that we clicked on that.
		 as we click on a button on screen, Cell class store button in cell variable 
		 so Cell.cell variable represent Button that we currently clicked on it. */
		int row = Integer.parseInt(Cell.cell.getToolTipText());
		for (int i = 2; i < Column.getcColumns(); i++) {
			c = (Cell) Column.Columns[i][row];
			int j = Integer.parseInt(c.getButton().getText());
			sum = sum + j;
		}
		avg = sum / (Column.getcColumns() - 2);
	
		Cell c1 = (Cell) Column.Columns[0][row];
		c1.getLabel().setText(avg + "");
		MyColor.setColor(Cell.cell, c1.getLabel());
		sum = 0;
		avg = 0;
	}
}
