import java.lang.reflect.InvocationTargetException;

public class Main {

	public static void main(String[] args) throws IllegalArgumentException, InvocationTargetException, NoSuchMethodException, SecurityException, InstantiationException, IllegalAccessException {
		// TODO Auto-generated method stub
		MainFrame frm = new MainFrame();
		
	}
	
}
