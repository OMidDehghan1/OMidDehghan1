import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.lang.reflect.InvocationTargetException;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class ColumnManager {

	public static void setColumns() throws InstantiationException, IllegalAccessException, IllegalArgumentException,
			InvocationTargetException, NoSuchMethodException, SecurityException {
		int xl = 0;
		int yl = 0;
		int xbm = 0;
		int ybm = 0;
		int xlm = 0;
		int ylm = 0;

		// =============================================== score header Section
//		Cell scHeader = new Cell(JLabel.class, 0, 0, 200, 200, "Average", "Average",	0);
//		JLabel headerlbl = scHeader.createCell().getLabel();
//	
//		headerlbl.setBackground(Color.red);
////		Panel p = new Panel(new FlowLayout(FlowLayout.CENTER ,3, 3),200, 200, Setting.ColumnsPan_COLOR);
//		
////		p.add();
//		MainFrame.scheaderPan.add(headerlbl);
		// =============================================== Main header Section

		// =============================================== Score Section
		Column sc = new Column(JLabel.class, "Average", "0", xl, yl, Setting.CELLS_WIDTH, Setting.CELLS_HEIGHT);
		sc.createColumn();
		sc.addToPanel(MainFrame.scorePan);

		// =============================================== Main Section
		Column sm = new Column(JLabel.class, "Number", "0", 0, 0, 20, Setting.CELLS_HEIGHT);
		sm.createColumn();
		sm.addToPanel(MainFrame.mainPan);

		Column mc = new Column(JButton.class, "Reading", "0", xlm, ybm, Setting.CELLS_WIDTH, Setting.CELLS_HEIGHT);
		mc.createColumn();
		mc.addToPanel(MainFrame.mainPan);

		Column gc = new Column(JButton.class, "Writing", "0", xlm, ybm, Setting.CELLS_WIDTH, Setting.CELLS_HEIGHT);
		gc.createColumn();
		gc.addToPanel(MainFrame.mainPan);

		Column ec = new Column(JButton.class, "english", "0", xlm, ybm, Setting.CELLS_WIDTH, Setting.CELLS_HEIGHT);
		ec.createColumn();
		ec.addToPanel(MainFrame.mainPan);

		Column tc = new Column(JButton.class, "waking", "0", xlm, ybm, Setting.CELLS_WIDTH, Setting.CELLS_HEIGHT);
		tc.createColumn();
		tc.addToPanel(MainFrame.mainPan);

		System.out.println(tc.getcColumns());

		// Cell c = (Cell) Column.Columns[0][100];
		// int x = c.getLabel().getX();
		// int y = c.getLabel().getY();
		// int width = c.getLabel().getWidth();
		// int height = c.getLabel().getHeight();
		// System.out.println(x);
		// System.out.println(y);
		// System.out.println(width);
		// System.out.println(height);
	}
}
