import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridLayout;
import java.awt.LayoutManager;

import javax.swing.JPanel;
import javax.swing.LayoutStyle;

public class Panel extends JPanel {

		public Panel(LayoutManager layout, int width, int height, Color color) {
			super();
			this.setPreferredSize(new Dimension(width, height));
			this.setOpaque(true);
			this.setBackground(color);
			this.setLayout(layout);
		}

		public Panel(int width, int height, Color color) {
			super();
			this.setPreferredSize(new Dimension(width, height));
			this.setOpaque(true);
			this.setBackground(color);
			this.setLayout(new FlowLayout());
			
		}
	}