import java.awt.Color;

public class Setting {
	public final static String NAME = "ODRATE0.2";
	
	public final static int Frame_WIDTH = 700;
	public final static int Frame_HEIGHT = 900;
	
	public final static int MAIN_FRAME_X = 300;
	public final static int MAIN_FRAME_Y = 50;
	
	public final static int CELLS_WIDTH = 80;
	public final static int CELLS_HEIGHT = 25;
	
	public final static int CELLS_DOWNMARGIN = 0;
	public final static int CELLS_LEFTMARGIN = 0;
	
	public final static int COLUMNS_CELLS_NUM = 365;
	
	public final static int DEFALUT_COLUMNS_NUM = 5;
	
	public final static int PANELS_HEIGHT = (COLUMNS_CELLS_NUM * (CELLS_HEIGHT + 11));
	
	public final static Color OptionPan_COLOR = new Color(239, 239, 200);
	public final static Color ColumnsPan_COLOR = new Color(239,239,239);
	public final static Color ScorePan_COLOR = new Color(239,239,239);
	public final static Color MainPan_COLOR = new Color(239, 239, 230);
	
	
	public final static int SCORE_BTNS_WIDTH = 60;
	public final static int SCORE_BTNS_HEIGHT = 63;
	
	public final static Color s0_20 = new Color(254, 0, 0, 255);
	public final static Color s20_40 = new Color(244, 199, 194, 255);
	public final static Color s40_60 = new Color(239, 194, 56, 255);
	public final static Color s60_80 = new Color(146, 196, 125, 255);
	public final static Color s80_90 = new Color(105, 168, 79, 255);
	public final static Color s90_100 = new Color(0, 255, 1, 255);
		
}
