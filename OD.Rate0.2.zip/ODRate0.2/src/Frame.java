import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLayeredPane;
import javax.swing.JPanel;
import javax.swing.JRootPane;
import javax.swing.JScrollPane;
import javax.swing.JViewport;

public class Frame extends JFrame implements MouseListener {

	public Frame(int x, int y, int width, int height, String name, boolean Resizablity) {
		super(name);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setSize(new Dimension(width, height));
		this.setResizable(Resizablity);
		this.setMinimumSize(new Dimension(width, height));
		this.setLocation(x, y);


	}

	public Frame(int x, int y, int width, int height) {
		super();
		this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		this.setSize(new Dimension(width, height));
		this.setResizable(false);
		this.setLocation(x, y);
		this.setLayout(new FlowLayout(FlowLayout.CENTER));
		this.setUndecorated(true);
		this.setBackground(Color.white);
	}

	public void createFrame() {

		JButton btn0 = new JButton("0");
		btn0.setPreferredSize(new Dimension(Setting.SCORE_BTNS_WIDTH, Setting.SCORE_BTNS_HEIGHT));
		btn0.setLocation(0, 0);
		btn0.setBackground(Setting.s0_20);
		btn0.setFocusable(false);
		
		JButton btn10 = new JButton("10");
		btn10.setPreferredSize(new Dimension(Setting.SCORE_BTNS_WIDTH, Setting.SCORE_BTNS_HEIGHT));
		btn10.setLocation(Setting.SCORE_BTNS_WIDTH, 0);
		btn10.setBackground(Setting.s0_20);
		btn10.setFocusable(false);
		
		JButton btn20 = new JButton("20");
		btn20.setPreferredSize(new Dimension(Setting.SCORE_BTNS_WIDTH, Setting.SCORE_BTNS_HEIGHT));
		btn20.setLocation((3 * Setting.SCORE_BTNS_WIDTH), 0);
		btn20.setBackground(Setting.s0_20);
		btn20.setFocusable(false);
		
		JButton btn25 = new JButton("25");
		btn25.setPreferredSize(new Dimension(Setting.SCORE_BTNS_WIDTH, Setting.SCORE_BTNS_HEIGHT));
		btn25.setLocation((4 * Setting.SCORE_BTNS_WIDTH), 0);
		btn25.setBackground(Setting.s20_40);
		btn25.setFocusable(false);
		
		JButton btn30 = new JButton("30");
		btn30.setPreferredSize(new Dimension(Setting.SCORE_BTNS_WIDTH, Setting.SCORE_BTNS_HEIGHT));
		btn30.setLocation((5 * Setting.SCORE_BTNS_WIDTH), 0);
		btn30.setBackground(Setting.s20_40);
		btn30.setFocusable(false);
		
		JButton btn40 = new JButton("40");
		btn40.setPreferredSize(new Dimension(Setting.SCORE_BTNS_WIDTH, Setting.SCORE_BTNS_HEIGHT));
		btn40.setLocation((6 * Setting.SCORE_BTNS_WIDTH), 0);
		btn40.setBackground(Setting.s20_40);
		btn40.setFocusable(false);
		
		JButton btn50 = new JButton("50");
		btn50.setPreferredSize(new Dimension(Setting.SCORE_BTNS_WIDTH, Setting.SCORE_BTNS_HEIGHT));
		btn50.setLocation((7 * Setting.SCORE_BTNS_WIDTH), 0);
		btn50.setBackground(Setting.s40_60);
		btn50.setFocusable(false);
		
		JButton btn60 = new JButton("60");
		btn60.setPreferredSize(new Dimension(Setting.SCORE_BTNS_WIDTH, Setting.SCORE_BTNS_HEIGHT));
		btn60.setLocation((8 * Setting.SCORE_BTNS_WIDTH), 0);
		btn60.setBackground(Setting.s40_60);
		btn60.setFocusable(false);
		
		JButton btn70 = new JButton("70");
		btn70.setPreferredSize(new Dimension(Setting.SCORE_BTNS_WIDTH, Setting.SCORE_BTNS_HEIGHT));
		btn70.setLocation((9 * Setting.SCORE_BTNS_WIDTH), 0);
		btn70.setBackground(Setting.s60_80);
		btn70.setFocusable(false);
		
		JButton btn75 = new JButton("75");
		btn75.setPreferredSize(new Dimension(Setting.SCORE_BTNS_WIDTH, Setting.SCORE_BTNS_HEIGHT));
		btn75.setLocation((10 * Setting.SCORE_BTNS_WIDTH), 0);
		btn75.setBackground(Setting.s60_80);
		btn75.setFocusable(false);
		
		JButton btn80 = new JButton("80");
		btn80.setPreferredSize(new Dimension(Setting.SCORE_BTNS_WIDTH, Setting.SCORE_BTNS_HEIGHT));
		btn80.setLocation((11 * Setting.SCORE_BTNS_WIDTH), 0);
		btn80.setBackground(Setting.s60_80);
		btn80.setFocusable(false);
		
		JButton btn90 = new JButton("90");
		btn90.setPreferredSize(new Dimension(Setting.SCORE_BTNS_WIDTH, Setting.SCORE_BTNS_HEIGHT));
		btn90.setLocation((12 * Setting.SCORE_BTNS_WIDTH), 0);
		btn90.setBackground(Setting.s80_90);
		btn90.setFocusable(false);
		
		JButton btn100 = new JButton("100");
		btn100.setPreferredSize(new Dimension(Setting.SCORE_BTNS_WIDTH, Setting.SCORE_BTNS_HEIGHT));
		btn100.setLocation((13 * Setting.SCORE_BTNS_WIDTH), 0);
		btn100.setBackground(Setting.s90_100);
		btn100.setFocusable(false);
		
		this.add(btn0);
		this.add(btn10);
		this.add(btn20);
		this.add(btn25);
		this.add(btn30);
		this.add(btn40);
		this.add(btn50);
		this.add(btn60);
		this.add(btn70);
		this.add(btn75);
		this.add(btn80);
		this.add(btn90);
		this.add(btn100);
		
		this.addMouseListener(this);

		btn0.addMouseListener(this);
		btn10.addMouseListener(this);
		btn20.addMouseListener(this);
		btn25.addMouseListener(this);
		btn30.addMouseListener(this);
		btn40.addMouseListener(this);
		btn50.addMouseListener(this);
		btn60.addMouseListener(this);
		btn70.addMouseListener(this);
		btn75.addMouseListener(this);
		btn80.addMouseListener(this);
		btn90.addMouseListener(this);
		btn100.addMouseListener(this);
	}


	@Override
	public void mouseClicked(MouseEvent g) {
		if (g.getSource() instanceof JButton) {
			JButton btn = (JButton) g.getSource();
			Cell.cell.setText(btn.getText());
			Calculator sc = new Calculator();
			sc.calculate();
		}
	}

	@Override
	public void mouseEntered(MouseEvent g) {
		// TODO Auto-generated method stub
	}

	@Override
	public void mouseExited(MouseEvent g) {
		// TODO Auto-generated method stub
		if (!(g.getSource() instanceof JFrame) && !(g.getSource() instanceof JButton))
			Cell.frm.dispose();

	}

	@Override
	public void mousePressed(MouseEvent arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseReleased(MouseEvent arg0) {
		// TODO Auto-generated method stub

	}
}
