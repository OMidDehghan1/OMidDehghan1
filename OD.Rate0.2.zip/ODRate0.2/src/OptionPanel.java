
public class OptionPanel {
	public static void setOptionPanelComponents() {
		
	}
}
