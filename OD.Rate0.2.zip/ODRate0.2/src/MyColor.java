import java.awt.Color;

import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JLabel;

public class MyColor extends Color{
	public MyColor(int r, int g, int b, int a) {
		super(r, g, b, a);
		// TODO Auto-generated constructor stub
	}

	// =========================================== Attributes
	private static JComponent component;
	public final static Color s0_20 = Setting.s0_20;
	public final static Color s20_40 = Setting.s20_40;
	public final static Color s40_60 = Setting.s40_60;
	public final static Color s60_80 = Setting.s60_80;
	public final static Color s80_90 = Setting.s80_90;
	public final static Color s90_100 = Setting.s90_100;
	
	// =========================================== Operations
	public static void setColor(JButton btn, JLabel lbl) {
		setColor(btn);
		setColor(lbl);
	}
	
	public static void setColor(JComponent c) {
		int score = 0;

		if (c instanceof JButton) {
			score = Integer.parseInt(((JButton) c).getText());
			component = (JButton) c;
		}
		if (c instanceof JLabel) {
			score = Integer.parseInt(((JLabel) c).getText());
			component = (JLabel) c;
		}

		if (score >= 0 && score <= 20) {
			component.setBackground(MyColor.s0_20);

		} else if (score > 20 && score <= 40) {
			component.setBackground(MyColor.s20_40);

		} else if (score > 40 && score <= 60) {
			component.setBackground(MyColor.s40_60);

		} else if (score > 60 && score <= 80) {
			component.setBackground(MyColor.s60_80);

		} else if (score > 80 && score <= 90) {
			component.setBackground(MyColor.s80_90);

		} else if (score > 90 && score <= 100) {
			component.setBackground(MyColor.s90_100);
		}
	}
}
