
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;
import java.lang.reflect.InvocationTargetException;

import javax.swing.JScrollPane;

public class MainFrame implements ComponentListener {

	public final static int WIDTH = Setting.Frame_WIDTH;
	public final static int HEIGHT = Setting.Frame_HEIGHT;
	public final static String NAME = "DailyHealth";
	public static Frame frame;

	private Panel gc1;
	private Panel gc2;

	public static Panel scorePan;
	public static Panel mainPan;
	public static Panel footerPan;
	public static Panel headerPan;
	public static Panel scheaderPan;
	public static int x = Setting.MAIN_FRAME_X;
	public static int y = Setting.MAIN_FRAME_Y;

	public static int width;
	public static int height;

	public MainFrame() throws IllegalArgumentException, InvocationTargetException, NoSuchMethodException,
			SecurityException, InstantiationException, IllegalAccessException {
		frame = new Frame(Setting.MAIN_FRAME_X, Setting.MAIN_FRAME_Y, Setting.Frame_WIDTH, Setting.Frame_HEIGHT,
				Setting.NAME, true);
		frame.addComponentListener(this);

		////////// Panels SECTION
		GridBagConstraints c = new GridBagConstraints();

		gc1 = new Panel(new GridBagLayout(), WIDTH - 50, Setting.Frame_HEIGHT, Setting.ColumnsPan_COLOR);

		gc2 = new Panel(new GridBagLayout(), WIDTH - 50, Setting.PANELS_HEIGHT, Setting.ColumnsPan_COLOR);

		scorePan = new Panel(new FlowLayout(FlowLayout.CENTER), Setting.CELLS_WIDTH + 3, Setting.PANELS_HEIGHT + 20,
				Setting.ScorePan_COLOR);

		mainPan = new Panel(new FlowLayout(FlowLayout.LEFT), Setting.DEFALUT_COLUMNS_NUM * Setting.CELLS_WIDTH,
				Setting.PANELS_HEIGHT + 20, Setting.MainPan_COLOR);

		footerPan = new Panel(new FlowLayout(FlowLayout.LEFT), 675, 60, Setting.OptionPan_COLOR);
//
//		headerPan = new Panel(null, Setting.DEFALUT_COLUMNS_NUM * Setting.CELLS_WIDTH, 60, Setting.ColumnsPan_COLOR);
//
//		scheaderPan = new Panel(new FlowLayout(),Setting.CELLS_WIDTH + 20, Setting.CELLS_HEIGHT + 20, Setting.ColumnsPan_COLOR);

		ColumnManager.setColumns();

		JScrollPane sp1 = new JScrollPane(scorePan);
		JScrollPane sp2 = new JScrollPane(mainPan);
//		JScrollPane sp3 = new JScrollPane(headerPan);
//		JScrollPane sp4 = new JScrollPane(scheaderPan);

		sp1.getVerticalScrollBar().setModel(sp2.getVerticalScrollBar().getModel());
		sp1.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_NEVER);

		sp2.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);

//		sp3.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_NEVER);
//		sp3.getHorizontalScrollBar().setModel(sp2.getHorizontalScrollBar().getModel());
//		sp3.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
//
//		sp4.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
//		sp4.getHorizontalScrollBar().setModel(sp2.getHorizontalScrollBar().getModel());
//		sp4.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
		//////////////////////////////////////////////////////// gc1

		c.fill = GridBagConstraints.BOTH;
		c.gridx = 0;
		c.gridy = 1;
		c.weightx = 1.0;
		c.weighty = 0.9;
		c.insets = new Insets(1, 1, 1, 1);
		gc1.add(gc2, c);

		c.gridx = 0;
		c.gridy = 2;
		c.weightx = 1.0;
		c.weighty = 0.1;
		c.insets = new Insets(1, 1, 1, 1);
		gc1.add(footerPan, c);

		///////////////////////////////////////////// gc2
//		c.fill = GridBagConstraints.BOTH;
//		c.gridx = 0;
//		c.gridy = 0;
//		c.weightx = 0.20;
//		c.weighty = 0.05;
//		c.insets = new Insets(1, 1, 1, 1);
//		gc2.add(sp4, c);
//
//		c.fill = GridBagConstraints.BOTH;
//		c.gridx = 1;
//		c.gridy = 0;
//		c.weightx = 0.80;
//		c.weighty = 0.05;
//		c.insets = new Insets(1, 1, 1, 1);
//		gc2.add(sp3, c);

		c.gridx = 0;
		c.gridy = 1;
		c.weightx = 0.20;
		c.weighty = 0.95;
		c.insets = new Insets(1, 1, 1, 1);
		gc2.add(sp1, c);

		c.gridx = 1;
		c.gridy = 1;
		c.weightx = 0.80;
		c.weighty = 0.95;
		c.insets = new Insets(1, 1, 1, 1);
		gc2.add(sp2, c);

		frame.add(gc1);
		frame.setVisible(true);
	}

	@Override
	public void componentHidden(ComponentEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void componentMoved(ComponentEvent e) {
		// TODO Auto-generated method stub
		if (e.getSource() instanceof Frame) {
			Frame frm = (Frame) e.getSource();
			x = frm.getX();
			y = frm.getY();
			if (Cell.frm != null)
				Cell.frm.setLocation(x + width, y + 2);
		}
	}

	@Override
	public void componentResized(ComponentEvent e) {
		// TODO Auto-generated method stub
		if (e.getSource() instanceof Frame) {
			Frame frm = (Frame) e.getSource();
			x = frm.getX();
			y = frm.getY();
			width = frm.getWidth();
			height = frm.getHeight();

			if (x != Setting.Frame_WIDTH && y != Setting.Frame_HEIGHT && Cell.frm != null)
				Cell.frm.setLocation(x + width, y + 2);
		}
	}

	@Override
	public void componentShown(ComponentEvent e) {
		// TODO Auto-generated method stub

	}
} // end of the class
