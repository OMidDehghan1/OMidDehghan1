
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.lang.reflect.InvocationTargetException;

import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JLayeredPane;
import javax.swing.JPanel;
import javax.swing.JRootPane;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.JViewport;
import javax.swing.SwingConstants;
import javax.swing.border.LineBorder;

public class Cell extends JComponent implements MouseListener {


	// ===================================== Attribute
	private Class aClass;
	private int x;
	private int y;
	private int width;
	private int height;
	private String title;
	private int row;

	private String text;

	public static Frame frm;

	private static int click = 1;

	public static JButton cell;

	private JButton btn;
	private JLabel lbl;

	// ===================================== Constructors

	public Cell(final Class aClass, int x, int y, int width, int height, String title, String text, int row)
			throws InstantiationException, IllegalAccessException, IllegalArgumentException, InvocationTargetException,
			NoSuchMethodException, SecurityException {
		this.setX(x);
		this.setY(y);
		this.setaClass(aClass);
		this.setWidth(width);
		this.setHeight(height);
		this.setText(text);
		this.setTitle(title);
		this.setRow(row);
	}

	// ===================================== Operators

	public Cell createCell() throws InstantiationException, IllegalAccessException, IllegalArgumentException,
			InvocationTargetException, NoSuchMethodException, SecurityException {

		if (aClass == JButton.class) {
			btn = (JButton) aClass.getConstructor().newInstance();
			btn.setPreferredSize(new Dimension(width, height));
			btn.setText(text);
			btn.addMouseListener(this);
			btn.setBackground(Color.white);
			btn.setToolTipText(Column.num + "");
			btn.setFocusable(false);
			btn.setBorder(new LineBorder(Color.black));

		} else if (aClass == JLabel.class) {
			lbl = (JLabel) aClass.getConstructor().newInstance();
			lbl.setPreferredSize(new Dimension(width, height));
			lbl.setLocation(x, y);
			lbl.setText(text);
			lbl.setHorizontalAlignment(SwingConstants.CENTER);
			lbl.setVerticalAlignment(SwingConstants.CENTER);
			lbl.setAlignmentX(CENTER_ALIGNMENT);
			lbl.setAlignmentY(CENTER_ALIGNMENT);
			lbl.setOpaque(true);
			lbl.setToolTipText(Column.num + "");
		}
		return this;
	}
	
	// ===================================== Mouse Events

	@Override
	public void mouseClicked(MouseEvent g) {
		// TODO Auto-generated method stub
		JButton btn = (JButton) g.getSource();
		cell = btn;
		if (g.getSource() instanceof JButton && click == 1) {
			frm = new Frame(MainFrame.frame.getX() + Setting.Frame_WIDTH, MainFrame.frame.getY() + 2,
					Setting.SCORE_BTNS_WIDTH + 2, (Setting.SCORE_BTNS_HEIGHT * 14 + 7));
			frm.createFrame();
			frm.setVisible(true);
			click++;
		}
	}

	@Override
	public void mouseEntered(MouseEvent g) {

	}

	@Override
	public void mouseExited(MouseEvent g) {

	}

	@Override
	public void mousePressed(MouseEvent arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseReleased(MouseEvent arg0) {
		// TODO Auto-generated method stub

	}

	// =================================================== Setter & getters
	
	public int getX() {
		return x;
	}

	public void setX(int x) {
		this.x = x;
	}

	public int getY() {
		return y;
	}

	public void setY(int y) {
		this.y = y;
	}

	public int getWidth() {
		return width;
	}

	public void setWidth(int width) {
		this.width = width;
	}

	public int getHeight() {
		return height;
	}

	public void setHeight(int height) {
		this.height = height;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public int getRow() {
		return row;
	}

	public void setRow(int row) {
		this.row = row;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}
	public JButton getButton() {
		return btn;
	}

	public JLabel getLabel() {
		return lbl;
	}

	public Class getaClass() {
		return aClass;
	}

	public void setaClass(Class aClass) {
		this.aClass = aClass;
	}

}// End of Class
