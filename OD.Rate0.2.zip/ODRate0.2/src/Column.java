import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.lang.reflect.InvocationTargetException;

import javax.swing.AbstractButton;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import org.omg.CORBA.COMM_FAILURE;

public class Column {

	// ================================================ Attribute
	private Class aClass;
	private String title;
	private String CellsText;
	private int x;
	private int y;
	private int width;
	private int height;

	private Panel p;

	public final static JComponent[][] Columns = new JComponent[50][365];
	private static int cColumns = 0;

	private Cell cell;
	private Cell titleLbl;
	private Cell[] cells;


	public static int num = 0;
	////////////////////////////////////////// Contractors

	public Column(final Class aClass, String title, String cellsText, int x, int y, int width, int height) {
		super();
		this.aClass = aClass;
		this.setX(x);
		this.setY(y);
		this.setWidth(width);
		this.setHeight(height);
		this.setTitle(title);
		this.setCellsText(cellsText);
	}

	////////////////////////////////////////// Operation

	public void createColumn() throws InstantiationException, IllegalAccessException, IllegalArgumentException,
			InvocationTargetException, NoSuchMethodException, SecurityException {

		// ======================================== Buttons
		
		if (aClass == JButton.class) {
			cells = new Cell[Setting.COLUMNS_CELLS_NUM];
			int xb = 0;
			int yb = 0;
//			if (num == 0) {
//				cell = new Cell(JLabel.class, xb, yb, getWidth(), getHeight(), getTitle(), getTitle(), 0);
//				titleLbl = (Cell) cell.createCell();
//				titleLbl.getLabel().setText(getTitle());
//				cells[0] = titleLbl;
//				num++;
//				
//				yb += Setting.CELLS_HEIGHT;
//			}

			for (int i = 0; i < cells.length; i++) {
				cell = new Cell(aClass, xb, yb, getWidth(), getHeight(), getTitle(), getCellsText(), num);

				cells[i] = (Cell) cell.createCell();
				num++;
				yb += Setting.CELLS_HEIGHT;
			}

			num = 0;
			Columns[cColumns] = cells;
			cColumns++;
		}
		// ======================================== Labels
		if (aClass == JLabel.class) {
			cells = new Cell[Setting.COLUMNS_CELLS_NUM];
			int xl = 0;
			int yl = 0;
//			if (num == 0) {
//				cell = new Cell(JLabel.class, xl, yl, getWidth(), getHeight(), getTitle(), getTitle(), 0);
//				titleLbl = (Cell) cell.createCell();
//				titleLbl.getLabel().setText(getTitle());
//				cells[0] = titleLbl;
//				num++;
//				yl += Setting.CELLS_HEIGHT;
//			}
			for (int i = 0; i < cells.length; i++) {
				cell = new Cell(aClass, xl, yl, getWidth(), getHeight(), this.title, getCellsText(), num);

				cells[i] = (Cell) cell.createCell();
				num++;
				yl += Setting.CELLS_HEIGHT;
			}
			num = 0;
			Columns[cColumns] = cells;
			cColumns++;
		}
	}

	public void addToPanel(Container con) {
		// ================================================= Button
		
		if (aClass == JButton.class) {
			p = new Panel(getWidth(), Setting.PANELS_HEIGHT, Setting.ColumnsPan_COLOR);
			
			for (int j = 0; j < cells.length; j++) {
				p.add(cells[j].getButton());
				con.add(p);
			}
			
			// ================================================= Label
		} else if (aClass == JLabel.class) {
			p = new Panel(getWidth(), Setting.PANELS_HEIGHT, Setting.ColumnsPan_COLOR);
			System.out.println(getTitle() + ": " + getWidth());
			for (int j = 0; j < cells.length; j++) {
				p.add(cells[j].getLabel());
				con.add(p);
			}
		}
	}

	////////////////////////////////////////// Setters and Getters

	public int getX() {
		return x;
	}

	public void setX(int x) {
		this.x = x;
	}

	public int getY() {
		return y;
	}

	public void setY(int y) {
		this.y = y;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public int getWidth() {
		return width;
	}

	public void setWidth(int width) {
		this.width = width;
	}

	public int getHeight() {
		return height;
	}

	public void setHeight(int height) {
		this.height = height;
	}

	public static int getcColumns() {
		return cColumns;
	}

	public String getCellsText() {
		return CellsText;
	}

	public void setCellsText(String cellsText) {
		CellsText = cellsText;
	}
}
